<?php
// Declare two variables
$number1 = 42;
$number2 = 56;

// Use the ternary operator to determine the larger number
$largerNumber = ($number1 > $number2) ? $number1 : $number2;

// Display the result
echo "The larger number between $number1 and $number2 is: $largerNumber";
?>