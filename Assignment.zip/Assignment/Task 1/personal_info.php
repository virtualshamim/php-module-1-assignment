<?php
        // Define variables
        $name = "Shamim Al Mamun";
        $age = 32;
        $country = "Bangladesh";
        $introduction = "Hello, I'm Shamim Al Mamun. I'm a web developer. I enjoy coding and learning new technologies.";

        // Display personal information
        echo "Name: " . $name . "<br>";
        echo "Age: " . $age . "<br>";
        echo "Country: " . $country . "<br>";
        echo "Introduction: " . $introduction;
?>